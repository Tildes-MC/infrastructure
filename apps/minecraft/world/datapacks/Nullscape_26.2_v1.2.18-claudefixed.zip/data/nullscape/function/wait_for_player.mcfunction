# Do the toast
execute unless score %USED tr.first matches 2.. run schedule function nullscape:toast 5t
scoreboard players set %USED tr.first 2